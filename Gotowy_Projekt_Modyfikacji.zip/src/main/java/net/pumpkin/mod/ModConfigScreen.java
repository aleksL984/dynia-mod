package net.pumpkin.mod;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class ModConfigScreen extends Screen {
    private final Screen parent;

    protected ModConfigScreen(Screen parent) {
        super(Text.literal("Konfiguracja Modu Automatyzacji Dyń"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int buttonWidth = 200;
        int buttonHeight = 20;
        
        Text buttonText = Text.literal("Automatyzacja: " + (PumpkinAutomationMain.isAutomationEnabled() ? "§aWŁĄCZONA" : "§cWYŁĄCZONA"));
        
        this.addSelectableChild(ButtonWidget.builder(buttonText, button -> {
            PumpkinAutomationMain.setAutomationEnabled(!PumpkinAutomationMain.isAutomationEnabled());
            button.setMessage(Text.literal("Automatyzacja: " + (PumpkinAutomationMain.isAutomationEnabled() ? "§aWŁĄCZONA" : "§cWYŁĄCZONA")));
        }).dimensions(this.width / 2 - buttonWidth / 2, this.height / 2 - 30, buttonWidth, buttonHeight).build());

        this.addSelectableChild(ButtonWidget.builder(Text.literal("Gotowe"), button -> {
            this.client.setScreen(this.parent);
        }).dimensions(this.width / 2 - buttonWidth / 2, this.height / 2 + 10, buttonWidth, buttonHeight).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
    
    @Override
    public void close() {
        this.client.setScreen(this.parent);
    }
}
