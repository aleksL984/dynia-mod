package net.pumpkin.mod;

public class ModConfig {
    public static int clickDelayTicks = 1;
    public static boolean silentSwapEnabled = true;
}
