package net.pumpkin.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class PumpkinAutomationMain implements ClientModInitializer {
    public static KeyBinding openConfigKey;
    public static KeyBinding toggleAutomationKey;
    private static boolean automationEnabled = false;

    @Override
    public void onInitializeClient() {
        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pumpkinautomation.config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "category.pumpkinautomation"
        ));

        toggleAutomationKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pumpkinautomation.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_MINUS,
                "category.pumpkinautomation"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (toggleAutomationKey.wasPressed()) {
                automationEnabled = !automationEnabled;
                client.player.sendMessage(Text.literal("Automatyzacja dyń: " + (automationEnabled ? "§aWŁĄCZONA" : "§cWYŁĄCZONA")), true);
            }

            while (openConfigKey.wasPressed()) {
                client.setScreen(new ModConfigScreen(client.currentScreen));
            }

            if (automationEnabled) {
                CarvingLogicController.tickAutomation(client);
            }
        });
    }

    public static boolean isAutomationEnabled() {
        return automationEnabled;
    }

    public static void setAutomationEnabled(boolean enabled) {
        automationEnabled = enabled;
    }
}
