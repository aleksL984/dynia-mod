package net.pumpkin.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.screen.slot.SlotActionType;

public class CarvingLogicController {
    private static int refillCooldown = 0;

    public static void tickAutomation(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null || client.world == null) return;
        if (client.currentScreen != null) return;

        ItemStack mainHand = client.player.getMainHandStack();
        ItemStack offHand = client.player.getOffHandStack();

        if (mainHand.isEmpty() || !mainHand.isOf(Items.SHEARS)) {
            return;
        }

        if (offHand.isEmpty() || !offHand.isOf(Items.PUMPKIN)) {
            if (refillCooldown <= 0) {
                trySilentRefill(client);
                refillCooldown = 2; 
            } else {
                refillCooldown--;
            }
            return;
        }

        HitResult hit = client.crosshairTarget;
        if (hit != null && hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult blockHit = (BlockHitResult) hit;
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, blockHit);
            client.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private static void trySilentRefill(MinecraftClient client) {
        PlayerInventory inventory = client.player.getInventory();
        int pumpkinSlot = -1;

        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getStack(i);
            if (!stack.isEmpty() && stack.isOf(Items.PUMPKIN)) {
                pumpkinSlot = i;
                break;
            }
        }

        if (pumpkinSlot != -1) {
            int slotId = pumpkinSlot;
            if (pumpkinSlot < 9) {
                slotId = pumpkinSlot + 36; 
            }
            
            client.interactionManager.clickSlot(
                client.player.currentScreenHandler.syncId,
                slotId,
                45, 
                SlotActionType.SWAP,
                client.player
            );
        }
    }
}
